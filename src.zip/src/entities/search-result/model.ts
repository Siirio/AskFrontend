export type ResultKind = "product" | "service" | "business";
export type Confidence = "high" | "medium" | "low";
export type SearchSection = "EXACT" | "OVER_BUDGET" | "WRONG_CITY" | "SIMILAR";

export type SearchResult = {
  id: string;
  kind: ResultKind;
  title: string;
  supplierName: string;
  branch: string;
  category: string;
  priceLabel?: string;
  confidence: Confidence;
  section?: SearchSection;
  score?: number;
  matchReasons?: string[];
  warnings?: string[];
  sourceLabel: string;
  note: string;
  actions: Array<"call" | "map" | "chat" | "request">;
};
